
class Academician {
    public String name;
    public int age;

    Academician(String name, int age){
        this.name = name;
        this.age = age;
    }

    public void studentSubject(String subject){
        System.out.println(name+", "+age+", "+subject);
    }
}

class Student extends Academician{

    public String grade;

    Student(String name, int age) {
        super(name, age);
    }

    @Override
    public void studentSubject(String subject) {
        super.studentSubject("I am a Student");
    }
    
}

class StudentApp{
    public static void main(String[] args) {
        Student student = new Student("Ari", 27);

        student.studentSubject("Matematika");
    }
}